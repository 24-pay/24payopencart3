<?php
// Heading
$_['heading_title']       = '24-pay';
$_['text_edit']           = 'Nastavenie platby cez 24-pay';

// Text
$_['text_extension']	    = 'Rošírenie';
$_['text_success']        = 'Úspech: zmeny boli uložené!';
$_['text_twentyfourpay']  = '<img src="view/image/payment/twentyfourpay.png" alt="24-pay" title="24-pay" style="border: 1px solid #EEEEEE; height:25px;" />';

// Entry
$_['entry_order_status']                = 'Order Status Completed';
$_['entry_order_status_completed_text'] = 'Stav zaplatená';
$_['entry_order_status_failed_text']    = 'Stav nezaplatená';
$_['entry_order_status_pending_text']   = 'Stav pending';
$_['entry_order_status_pending']        = 'Order Status Pending';
$_['entry_order_status_expiredate']     = 'Order Status Expiredate';
$_['entry_order_status_canceled']       = 'Order Status Canceled';
$_['entry_order_status_failed']         = 'Order Status Failed';
$_['entry_order_status_processing']     = 'Order Status Processing';

$_['entry_geo_zone']         = 'Geo Zone';
$_['entry_status']           = 'Stav modulu';
$_['entry_sort_order']       = 'Poradie';

$_['validate_params']       = 'Overiť zadané parametre';
$_['validate_params_title'] = 'Overenie nastavených parametrov';
$_['debug_param']           = 'Debug parameter';
$_['debug_param_on']        = 'zapnúť debug';
$_['test_param']            = 'Testovacie prostredie';
$_['test_param_on']         = 'zapnúť testovanie';
$_['notification_email']    = 'Chcete dostávať notifikačný email o platbe z 24-pay';
$_['receive_email']         = 'áno chcem na nižšie uvedený email';

$_['notify_client']         = 'Chcete posielat klientovi notifikačný email o stave platby z 24-pay';
$_['notify_client_on']      = 'Áno chcem';

$_['save_transaction_email'] = 'Poslať mail s offline linkom na platbu v prípade platby bez odpovede alebo zamietnutej platby.';
$_['save_transaction_email_on'] = 'Poslať';

$_['cart'] = 'Zahrnúť Košík a doprava, povinné iba v prípade platobnej metódy na splátky';
$_['cart_on'] = 'Zahrnúť';

$_['direct_google_pay']     = 'Zobraziť možnosť priamej platby cez Google Pay';
$_['direct_google_pay_on']  = 'Zobraziť';

$_['direct_apple_pay']      = 'Zobraziť možnosť priamej platby cez Apple Pay';
$_['direct_apple_pay_on']   = 'Zobraziť';

// Error
$_['error_permission']      = 'Warning: You do not have permission to modify the payment module!';
$_['error_mid'] = 'Parameter MID je povinný!';
$_['error_eshopid'] = 'Parameter Eshop Id je povinný!';
$_['error_key'] = 'Parameter Key je povinný!';
$_['error_email'] = 'Parameter Email je povinný!';
$_['error_email_format'] = 'Parameter Email je v nesprávnom tvare!';
?>
