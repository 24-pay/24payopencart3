<?php
// Heading
$_['heading_title']       = '24-pay';
$_['text_edit']           = 'Edit configuration';

// Text
$_['text_extension']      = 'Extensions';
$_['text_success']        = 'Success: You have modified payment module!';
$_['text_twentyfourpay']  = '<img src="view/image/payment/twentyfourpay.png" alt="24-pay" title="24-pay" style="border: 1px solid #EEEEEE; height:25px;" />';

// Entry
$_['entry_order_status']                = 'Order Status Completed';
$_['entry_order_status_completed_text'] = 'Completed Status';
$_['entry_order_status_failed_text']    = 'Failed Status';
$_['entry_order_status_pending_text']   = 'Pending Status';
$_['entry_order_status_pending']        = 'Order Status Pending';
$_['entry_order_status_expiredate']     = 'Order Status Expiredate';
$_['entry_order_status_canceled']       = 'Order Status Canceled';
$_['entry_order_status_failed']         = 'Order Status Failed';
$_['entry_order_status_processing']     = 'Order Status Processing';

$_['entry_geo_zone']         = 'Geo Zone';
$_['entry_status']           = 'Status';
$_['entry_sort_order']       = 'Sort Order';

$_['validate_params']       = 'Validate params';
$_['validate_params_title'] = '24pay params validation';
$_['debug_param']           = 'Debug parameter';
$_['debug_param_on']        = 'Debug ON';
$_['test_param']            = 'Test environment';
$_['test_param_on']         = 'Test ON';

$_['notification_email']    = 'Receive notification email from 24-pay';
$_['receive_email']         = 'Receive';

$_['notify_client']         = 'Send payment status email to client';
$_['notify_client_on']      = 'Send';

$_['save_transaction_email'] = 'Send offline payment link in case of no response or declined payment';
$_['save_transaction_email_on'] = 'Send';

$_['cart'] = 'Include cart & shipping, required only for the pay later payment method';
$_['cart_on'] = 'Include';

$_['direct_google_pay']     = 'Show direct Google Pay payment option';
$_['direct_google_pay_on']  = 'Show';

$_['direct_apple_pay']      = 'Show direct Apple Pay payment option';
$_['direct_apple_pay_on']   = 'Show';

// Error
$_['error_permission']      = 'Warning: You do not have permission to modify the payment module!';
$_['error_mid']             = 'Merchant Identificator (MID) is required!';
$_['error_eshopid']         = 'Eshop Id is required!';
$_['error_key']             = 'Shop secret key required!';
$_['error_email']           = 'Email is required!';
$_['error_email_format']    = 'Email is invalid!';
?>
